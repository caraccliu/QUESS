
#usage ./dl_miseq.sh <out_dir>

#MiSeq datasets

./dl_fastq.sh ${1} SRR5230111 NC_017279.1 1635045
./dl_fastq.sh ${1} SRR5075712 NC_000913.3 4641652
./dl_fastq.sh ${1} SRR4417428 NC_003098.1 2038615
./dl_fastq.sh ${1} SRR5181392 NC_003210.1 2944528
./dl_fastq.sh ${1} SRR5164004 NC_003197.2 4951383
./dl_fastq.sh ${1} SRR5110368 NC_007795.1 2821361
./dl_fastq.sh ${1} SRR4423181 NC_000962.3 4411532
./dl_fastq.sh ${1} ERR1485307 NC_002505.1 4033464
./dl_fastq.sh ${1} SRR2317595 NC_001133.9 12157105
./dl_fastq.sh ${1} SRR5146462 NC_016845.1 5682322
