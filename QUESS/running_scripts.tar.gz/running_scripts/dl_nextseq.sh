
#usage ./dl_miseq.sh <out_dir>

#MiSeq datasets
 
#./dl_fastq.sh ${1} ERR1845153 NC_007795.1 2821361
#./dl_fastq.sh ${1} SRR5336197 NC_000913.3 4641652
#./dl_fastq.sh ${1} SRR5088142 NC_003210.1 2944528
#./dl_fastq.sh ${1} SRR5251561 NC_001133.9 12157105
#./dl_fastq.sh ${1} SRR5381280 NC_003197.2 4951383
#./dl_fastq.sh ${1} SRR5093762 NC_016845.1 5682322
./dl_fastq.sh ${1} SRR3285619 NC_004354.4 143726002
